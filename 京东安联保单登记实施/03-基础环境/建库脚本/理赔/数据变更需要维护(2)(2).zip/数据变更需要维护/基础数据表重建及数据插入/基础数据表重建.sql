/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : ins_claim

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2019-11-09 16:21:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for commondata
-- ----------------------------
DROP TABLE IF EXISTS `commondata`;
CREATE TABLE `commondata` (
  `ID` decimal(16,0) NOT NULL COMMENT '主键',
  `DATATYPE` varchar(22) NOT NULL COMMENT '数据类型',
  `DATACODE` varchar(22) NOT NULL COMMENT '数据代码',
  `DATANAME` varchar(200) NOT NULL COMMENT '数据名称',
  `PRETYPE` varchar(200) DEFAULT NULL COMMENT '父节点类型',
  `PRECODE` varchar(22) DEFAULT NULL COMMENT '父节点代码',
  `VALIDSTATUS` varchar(2) DEFAULT NULL COMMENT '有效标识',
  `INSERTTIMEFORHIS` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '插入时间',
  `OPERATETIMEFORHIS` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`ID`),
  KEY `IDX_COMMONDATA_DATATYPE_CODE` (`DATATYPE`,`DATACODE`) USING BTREE,
  KEY `IDX_COMMONDATA_PRECODE` (`PRECODE`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='公共数据表';

-- ----------------------------
-- Table structure for prpdaddress
-- ----------------------------
DROP TABLE IF EXISTS `prpdaddress`;
CREATE TABLE `prpdaddress` (
  `CODE` varchar(12) NOT NULL COMMENT '行政区划代码',
  `NAME` varchar(40) NOT NULL COMMENT '行政区划名称',
  `PARENT` varchar(12) DEFAULT NULL COMMENT '行政区划附属',
  `VALIDSTATUS` varchar(1) DEFAULT '1' COMMENT '有效标识',
  `INSERTTIMEFORHIS` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '插入时间',
  `OPERATETIMEFORHIS` datetime DEFAULT NULL COMMENT '更新时间',
  KEY `IDX_PRPDADDRESS_PARENT` (`PARENT`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='行政区划表';

-- ----------------------------
-- Table structure for prpdbank
-- ----------------------------
DROP TABLE IF EXISTS `prpdbank`;
CREATE TABLE `prpdbank` (
  `BANKCODE` varchar(12) NOT NULL COMMENT '银行编码',
  `BANKNAME` varchar(100) NOT NULL COMMENT '银行名称',
  `BANKNATURE` varchar(2) DEFAULT NULL COMMENT '银行性质',
  `FLAG` varchar(10) DEFAULT NULL,
  `ARTICLECODE` varchar(60) DEFAULT NULL COMMENT '专项代码',
  `BANKID` varchar(12) DEFAULT NULL COMMENT '资金银行代码',
  `INSERTTIMEFORHIS` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '插入时间',
  `OPERATETIMEFORHIS` datetime DEFAULT NULL COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='银行表';

-- ----------------------------
-- Table structure for prpdhospital
-- ----------------------------
DROP TABLE IF EXISTS `prpdhospital`;
CREATE TABLE `prpdhospital` (
  `CODE` varchar(8) NOT NULL COMMENT '医院代码',
  `NAME` varchar(200) DEFAULT NULL COMMENT '医院名称',
  `PROVINCE` varchar(30) DEFAULT NULL COMMENT '医院所在省名称',
  `CITY` varchar(50) DEFAULT NULL COMMENT '医院所在市名称',
  `AREA` varchar(50) DEFAULT NULL COMMENT '医院所在区县名称',
  `LEVELS` varchar(10) DEFAULT NULL COMMENT '医院级数',
  `GRADE` varchar(10) DEFAULT NULL COMMENT '医院等类',
  `INSERTTIMEFORHIS` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '插入时间',
  `OPERATETIMEFORHIS` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='医院表';

-- ----------------------------
-- Table structure for prpdnode
-- ----------------------------
DROP TABLE IF EXISTS `prpdnode`;
CREATE TABLE `prpdnode` (
  `NODECODE` varchar(30) NOT NULL COMMENT '节点代码',
  `NODENAME` varchar(25) NOT NULL COMMENT '节点名称',
  `UPPERNODE` varchar(25) NOT NULL COMMENT '节点上级',
  `SERIALNO` decimal(4,0) DEFAULT NULL,
  `VALIDSTATUS` varchar(10) NOT NULL COMMENT '有效状态',
  `ACCEPTOVERMINUTES` decimal(6,0) DEFAULT NULL,
  `OUTOVERMINUTES` decimal(6,0) DEFAULT NULL,
  `NODETYPE` varchar(25) DEFAULT NULL COMMENT '节点类型',
  `REMARK` varchar(20) NOT NULL COMMENT '备注',
  `CREATETIME` datetime DEFAULT NULL COMMENT '创建时间',
  `CREATEUSER` varchar(25) DEFAULT NULL COMMENT '创建人',
  `UPDATETIME` datetime DEFAULT NULL COMMENT '修改时间',
  `UPDATEUSER` varchar(25) DEFAULT NULL COMMENT '修改人',
  `INSERTTIMEFORHIS` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '插入时间',
  `OPERATETIMEFORHIS` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`NODECODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='工作流节点表';

-- ----------------------------
-- Table structure for prpdmaimitem
-- ----------------------------
DROP TABLE IF EXISTS `prpdmaimitem`;
CREATE TABLE `prpdmaimitem` (
  `ID` decimal(16,0) NOT NULL COMMENT 'id',
  `MAIMITEM` varchar(255) NOT NULL COMMENT '评残项目名称',
  `MAIMLEVEL` varchar(2) NOT NULL COMMENT '伤残等级',
  `MAIMCODE` varchar(150) DEFAULT NULL COMMENT '项目编号',
  `STANDARD` varchar(1) NOT NULL COMMENT '有效标识',
  `INSERTTIMEFORHIS` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '插入时间',
  `OPERATETIMEFORHIS` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='评残项目表';
SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for prpdcoderisk
-- ----------------------------
DROP TABLE IF EXISTS `prpdcoderisk`;
CREATE TABLE `prpdcoderisk` (
  `CODETYPE` varchar(20) NOT NULL COMMENT '对照类型类型',
  `CODECODE` varchar(20) NOT NULL COMMENT '出险原因代码',
  `RISKCODE` varchar(10) NOT NULL COMMENT '险类代码',
  `INSERTTIMEFORHIS` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '插入时间',
  `OPERATETIMEFORHIS` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`CODETYPE`,`CODECODE`,`RISKCODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='险种与出险原因对照表';

-- ----------------------------
-- Table structure for prpdcity
-- ----------------------------
DROP TABLE IF EXISTS `prpdcity`;


-- ----------------------------
-- Table structure for prpdcountry
-- ----------------------------
DROP TABLE IF EXISTS `prpdcountry`;


